``tornado.template`` --- Flexible output generation
===================================================

.. automodule:: tornado.template
   :members:   
