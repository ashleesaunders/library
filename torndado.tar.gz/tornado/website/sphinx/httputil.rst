``tornado.httputil`` --- Manipulate HTTP headers and URLs
=========================================================

.. automodule:: tornado.httputil
   :members:
