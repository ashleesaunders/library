``tornado.websocket`` --- Bidirectional communication to the browser
====================================================================

.. automodule:: tornado.websocket
   :members:
