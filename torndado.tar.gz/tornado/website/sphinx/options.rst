``tornado.options`` --- Command-line parsing
============================================

.. automodule:: tornado.options
   :members:
