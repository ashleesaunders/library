Release notes
=============

.. toctree::
   :maxdepth: 2

   releases/next
   releases/v2.0.0
   releases/v1.2.1
   releases/v1.2.0
   releases/v1.1.1
   releases/v1.1.0
   releases/v1.0.1
   releases/v1.0.0
